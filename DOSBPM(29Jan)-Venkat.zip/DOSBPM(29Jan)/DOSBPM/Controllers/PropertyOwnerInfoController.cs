﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerInfoController : Controller
    {
        // GET: PropertyOwnerInfo
        public ActionResult Index()
        {
            Log.Info("Property Owner Info Controller Started");

            return View();
            
        }
    }
}