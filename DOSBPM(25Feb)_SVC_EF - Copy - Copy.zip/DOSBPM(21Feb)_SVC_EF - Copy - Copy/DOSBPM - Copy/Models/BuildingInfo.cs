﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class BuildingInfo
    {
        public string County { get; set; }
        public string Country { get; set; }

        public string Directions { get; set; }
    }
}