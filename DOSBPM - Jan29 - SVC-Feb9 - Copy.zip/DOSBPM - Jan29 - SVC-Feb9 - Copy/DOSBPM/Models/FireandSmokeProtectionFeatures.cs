﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class FireandSmokeProtectionFeatures
    {
        public string BarrierLocations { get; set; }

        public string PartitionLocations { get; set; }

        public string AddtionalFeatures { get; set; }
    }
}