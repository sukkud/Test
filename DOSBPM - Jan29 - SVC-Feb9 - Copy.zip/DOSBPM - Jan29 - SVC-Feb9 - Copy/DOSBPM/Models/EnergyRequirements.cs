﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DOSBPM.Controllers;

namespace DOSBPM.Models
{
    public class EnergyRequirements
    {
        public string ddlClimateZone { get; set; }

        public string ddlCompliancePath { get; set; }

        public string ddlSelectSoftware { get; set; }
    }
}