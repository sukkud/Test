﻿using DOSBPM.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerOrganizationController : BaseController
    {
        // GET: PropertyOwnerOrganization
        DEV_CODES_APPDBEntities appdbEntities = new DEV_CODES_APPDBEntities();

        public ActionResult Index()
        {

            var objList = new PropertyOwnerOrganization();
  
            objList.CountryList = GetCountries();
            objList.StatesList = GetStates();
            objList.CountiesList = GetCounties();

            return View(objList);
        }
       


    }



}

