﻿using DOSBPM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerContactController : BaseController
    {
        // GET: PropertyOwnerContact
        public ActionResult Index()
        {
            var objList = new PropertyOwnerOrganization();

            objList.CountryList = GetCountries();
            objList.StatesList = GetStates();
            objList.CountiesList = GetCounties();

            return View(objList);
        }
    }
}