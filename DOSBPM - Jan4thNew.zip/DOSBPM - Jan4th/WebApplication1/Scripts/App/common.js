﻿var common = (function () {
    var publicMethods = {};

    publicMethods.ajaxGet = function () {

    }

    return publicMethods;
})();