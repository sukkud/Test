﻿var qualify = (function () {

    var publicMethods = {};

    publicMethods.init = function () {

        $("#TransactionType").on("change", qualify.onTransactionTypeChange);

        $('input[type="checkbox"]').on('change', function () {
            $('input[type="checkbox"]').not(this).prop('checked', false);
        });
    }

    publicMethods.onTransactionTypeChange = function () {
        var selectedType = $(this).val();
        if (selectedType == "Demoloition Permit Application") {
            $("#divDPA").show();
            $("#divBPA").hide();

            $('#chkPD,#chkED').prop('checked', false)
        } else {
            $("#divBPA").show();
            $("#divDPA").hide();
            $('#chkEB,#chkNB').prop('checked', false)
        }
    }

    publicMethods.onNextBtnClick = function () {
        var selectedValue = $("#TransactionType").val();
        if (selectedValue == "Building Permit Application") {
            var ischkEB = $("#chkEB:checked").length==1;
            var ischkNB = $("#chkNB:checked").length == 1;
            if (ischkEB || ischkNB) {
                window.location.href = 'PropertyOwnerInfo';
            } else {
                alert(messages.qualifying.validation);
            }
        } else if (selectedValue == "Demoloition Permit Application"){
            var ischkPD = $("#chkPD:checked").length == 1;
            var ischkED = $("#chkED:checked").length == 1;
            if (ischkPD || ischkED) {
                window.location.href = 'PropertyOwnerInfo';
            } else {
                alert(messages.qualifying.validation);
            }
        } else {
            alert(messages.qualifying.dropdown_validation);
        }
    }

    return publicMethods;
})();