﻿var messages = (function () {
    var msgs = {};

    msgs.qualifying = {};
    msgs.qualifying.validation = "please select any checkbox";
    msgs.qualifying.dropdown_validation = "Please select any transaction type.";

    return msgs;
})();