﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class AdditionalStakeholderOrganizationController : Controller
    {
        // GET: AdditionalStakeholderOrganization
        public ActionResult Index()
        {
            return View();
        }
    }
}