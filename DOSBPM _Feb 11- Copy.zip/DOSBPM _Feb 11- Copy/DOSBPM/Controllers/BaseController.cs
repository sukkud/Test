﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class BaseController : Controller
    {
        BPMDataBaseEntities bpmEntity = new BPMDataBaseEntities();
        public SelectList GetStates()
        {
            return new SelectList(bpmEntity.States, "StateID", "StateName"); ;
        }

        public SelectList GetCountries()
        {
            return new SelectList(bpmEntity.Countries, "CountryID", "CountryName");
        }
        public SelectList GetCounties()
        {
            return new SelectList(bpmEntity.Countries, "CountryID", "CountryName");
        }
    }
}