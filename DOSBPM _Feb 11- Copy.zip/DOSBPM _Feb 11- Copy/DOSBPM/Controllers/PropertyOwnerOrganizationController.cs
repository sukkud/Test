﻿using DOSBPM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerOrganizationController : BaseController
    {

        // GET: PropertyOwnerOrganization
        public ActionResult Index()
        {
            PropertyOwnerOrganization propertyOwnerOrganization = new PropertyOwnerOrganization();
            propertyOwnerOrganization.StatesList = GetStates();
            propertyOwnerOrganization.Countries = GetCountries();
            return View(propertyOwnerOrganization);


        }

        
    }
}
