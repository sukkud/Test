﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class ConstructionMaterialsController : Controller
    {
        // GET: ConstructionMaterials
        public ActionResult Index()
        {
            return View();
        }
    }
}