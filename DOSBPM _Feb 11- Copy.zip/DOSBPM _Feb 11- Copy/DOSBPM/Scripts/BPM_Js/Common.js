﻿var common = (function () {
	var publicMethods = {};

	publicMethods.validate = function (pageId) {
		var isValid = true;
		var page = $("#" + pageId);
		var controls = page.find("[required=TRUE]");
		var allControls = controls.filter("[type='text'],select");
		
		$.each(allControls, function () {
			if ($.trim($(this).val()) == "") {
				isValid = false;				
				$(this).addClass("ValidationError");
				$(this).blur(function () {
					if ( $.trim($(this).val()) != "") {
						$(this).removeClass("ValidationError");
					} else {
						$(this).addClass("ValidationError");
					}
				});
			} else {
				$(this).removeClass("ValidationError");
			}
		});

        //custom rules
        $.each(allControls, function () {

        });

    var validation = {
                isEmailAddress: function (str) {
                    var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                    return pattern.test(str);  // returns a boolean
                },
                isNotEmpty: function (str) {
                    var pattern = /\S+/;
                    return pattern.test(str);  // returns a boolean
                },
                isNumber: function (str) {
                    var pattern = /^\d+$/;
                    return pattern.test(str);  // returns a boolean
                },
                isSame: function (str1, str2) {
                    return str1 === str2;
                }
            };   

		return isValid;
	}

	return publicMethods;
})();