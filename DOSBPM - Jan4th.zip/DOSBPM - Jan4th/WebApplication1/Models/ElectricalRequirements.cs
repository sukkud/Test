﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class ElectricalRequirements
    {
        public string ddlTypeofSystem { get; set; }

        public string ddlLoadAnalysis { get; set; }
    }
}