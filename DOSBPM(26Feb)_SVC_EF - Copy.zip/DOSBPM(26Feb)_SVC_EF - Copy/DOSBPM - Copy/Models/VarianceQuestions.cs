﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class VarianceQuestions
    {

        public string Variance { get; set; }
        public int petitionNumber { get; set; }
        public string ApplicantComment { get; set; }
        public string ReviewrComment { get; set; }
    }
}