﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Configuration;
using System.Data.SqlClient;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerInfoController : BaseController
    {
        // GET: PropertyOwnerInfo
        DEV_CODES_APPDBEntities appdbEntities = new DEV_CODES_APPDBEntities();

        public ActionResult Index()
        {

            var objList = new PropertyOwnerOrganization();
            objList.StatesList = GetStates();
            objList.CountryList = GetCountries();

            objList.CountiesList = GetCounties();

            return View(objList);
        }
    }
}