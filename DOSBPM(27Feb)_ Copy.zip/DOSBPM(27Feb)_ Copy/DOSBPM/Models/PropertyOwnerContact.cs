﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class PropertyOwnerContact
    {
        //public string ContactPerson { get; set; }
       
        //public string FirstName { get; set; }
        //public string MiddleName { get; set; }
        
        //public string LasttName { get; set; }
        //public string Suffix { get; set; }
        
        //public int TelephoneNumber { get; set; }
       
        //public string EmailAddress { get; set; }
        
        //public string MailingAddressLine1 { get; set; }
        //public string MailingAddressLine2 { get; set; }
        
        //public string City { get; set; }
        
        //public string State { get; set; }
        
        //public int Zip { get; set; }
        //public int Zip4 { get; set; }
        
        //public string County { get; set; }
        
        //public string Country { get; set; }
        //public string Comments { get; set; }
      
    }
}